<template>
<main>
     <NavBar />
  <v-container>
     <v-row>
      <v-col cols="12">
            <h1>About</h1>
            <p>
Work began on The Academy series in 2015 after the release of the Tara trilogy of games on vdategames.com. The first eight installments of the Academy were created and released over a period of about four years up until 2019.<br/><br/>
After a period of some uncertainty as to the whereabouts of the games' creator, it emerged that despite rumors of an untimely demise, work had never stopped on the series.
<br/><br/>
While completing on a further two episodes, a decision had also been taken to update the older episodes and bring them up to a consistent quality. At the same time, it was decided to release the new and remastered episodes on a custom-built platform.<br/><br/>
It also gave dsp3000 an opportunity to improve and expand upon elements of the story.
<br/><br/>
During 2022/2023 an ambitious schedule of release has been set.
<br/><br/>
A new <b>Introductory Episode</b> available April 2022 : 180 pages : 478 images<br/>
<br/>
<b>Chapters One and Two </b> were originally released in April 2016 as 'Academy: Part One' : 1230 pages : 997 images<br/>
This part of the story takes place during Monday morning and afternoon.<br/>
The remastered and expanded versions released May 2022: 1600 pages : 1732 images<br/>
<br/>
<b>Chapters Three and Four</b> were originally released in July 2016 as 'Academy: Part Two' : 1851 pages : 1500 images<br/>
This part of the story takes place during Tuesday morning, afternoon and early evening.<br/>
The remastered and expanded versions released June/August 2022 : 2610 pages : 3831 images<br/>
<br/>
<b>Chapters Five and Six</b> were originally released in December 2016 as 'Academy: Part Three' : 2264 pages : 1797 images<br/>
This part of the story takes place during Wednesday morning, afternoon and evening.<br/>
The remastered and expanded versions released September/November 2022 : 3250 pages : 4314 images<br/>
<br/>
<b>Chapters Seven and Eight</b> were originally released in May 2017 as 'Academy: Part Four' : 2226 pages : 1824 images<br/>
This part of the story takes place during Thursday morning and afternoon.<br/>
The remastered and expanded versions released December 2022/February 2023 : 3540 pages : 5880 images<br/>
<br/>
<b>Chapter Nine</b> was originally released in December 2017 as 'A Date with Bridgette : Part One' : 967 pages : 848 images<br/>
This part of the story takes place during early evening on Thursday.<br/>
The remastered and expanded version released April 2023 : 2370 pages : 3640 images<br/>
<br/>
<b>Chapter Ten</b> was originally released in January 2018 as 'A Date with Bridgette : Part Two' : 1666 pages : 2287 images<br/>
This part of the story takes place later on during Thursday evening.<br/>
The remastered and expanded version released June 2023 : 2610 pages : 3340 images<br/>
<br/>
<b>Chapter Eleven</b> was originally released in March 2019 as 'A Date with Bridgette : Part Three' : 2667 pages : 3542 images<br/>
This part of the story takes place during Thursday evening.<br/>
The remastered and expanded version splits the original episode and adds additional alternative scenes.<br />
Released July 2023 : 2340 pages : 3645 images<br/>
<br/>
<b>Chapter Twelve</b> was originally released in March 2019 as 'A Date with Bridgette : Part Three' : 2667 pages : 3542 images<br/>
This part of the story takes place late on Thursday evening.<br/>
The remastered and expanded version splits the original episode and adds additional alternative scenes.<br />
Chapter Twelve is in advanced remake/production stage :<br/>
New release date TBC<br/>
<br/>
<b>Chapter Thirteen</b> was originally released in October 2019 as 'A Date with Bridgette : Part Four' : 1762 pages : 4531 images<br/>
This part of the story will take place during late on Thursday night/Friday morning.<br/>
Chapter Thirteen will be released after some minor modifications :<br/>
New release date TBC<br/>
<br/>
<b>Chapter Fourteen</b> Completed mid 2021 - yet to be released : 2900 pages<br/>
This part of the story will take place during Friday morning.<br/>
This brand new chapter is complete subject to testing :<br/>
Release date TBC<br/>
<br/>
<b>Chapter Fifteen</b> In early stages of production :<br/>
This part of the story will take place during Friday afternoon.<br/>
Release date TBC<br/>
<br/>
<b>Chapter Sixteen</b> In early stages of production : <br/>
Release date TBC<br/>
<br/><br/>
</p>
      </v-col>
      </v-row>
    </v-container>
</main>
</template>



