<template>
<main>
     <NavBar />
  <v-container>
     <v-row>
      <v-col cols="12">
            <h1>Characters</h1>
      </v-col>
       </v-row>
       <v-row  class="pt-5">
            <h2> STAFF MEMBERS </h2>
    </v-row>
            <v-row>
        <v-col cols="4">
           <img src="imgs/characters/character_profiles_bridgette.jpg">
      </v-col>
       <v-col cols="4">
           <img src="imgs/characters/character_profiles_jodie.jpg">
      </v-col>
        <v-col cols="4">
           <img src="imgs/characters/character_profiles_didi.jpg">
      </v-col>
         <v-col cols="4">
           <img src="imgs/characters/character_profiles_principal.jpg">
      </v-col>
	  	 <v-col cols="4">
           <img src="imgs/characters/character_profiles_olivia.jpg">
      </v-col>
      </v-row>
          <v-row class="pt-5">
            <h2> CLASS MEMBERS </h2>
                </v-row>
            <v-row>
        <v-col cols="4">
           <img src="imgs/characters/character_profiles_annie.jpg">
      </v-col>
         <v-col cols="4">
           <img src="imgs/characters/character_profiles_amy.jpg">
      </v-col>
         <v-col cols="4">
           <img src="imgs/characters/character_profiles_lola.jpg">
      </v-col>
         <v-col cols="4">
           <img src="imgs/characters/character_profiles_laura.jpg">
      </v-col>
	  	 <v-col cols="4">
           <img src="imgs/characters/character_profiles_alicia.jpg">
      </v-col>
         <v-col cols="4">
           <img src="imgs/characters/character_profiles_genevieve.jpg">
      </v-col>
           <v-col cols="4">
           <img src="imgs/characters/character_profiles_isabella.jpg">
      </v-col>
          <v-col cols="4">
           <img src="imgs/characters/character_profiles_megan.jpg">
      </v-col>
          <v-col cols="4">
           <img src="imgs/characters/character_profiles_holly.jpg">
      </v-col>
          <v-col cols="4">
           <img src="imgs/characters/character_profiles_maria.jpg">
      </v-col>
      </v-row>
	  <v-row  class="pt-5">
            <h2> OTHER CHARACTERS </h2>
    </v-row>
            <v-row>
        <v-col cols="4">
           <img src="imgs/characters/character_profiles_natalia.jpg">
      </v-col>
	    <v-col cols="4">
           <img src="imgs/characters/character_profiles_alexia.jpg">
      </v-col>
      </v-row>
            <v-row  class="pt-5">
            <h2> MALE MEMBERS </h2>
                </v-row>
            <v-row>
        <v-col cols="4">
           <img src="imgs/characters/character_profiles_sebastian.jpg">
      </v-col>
	  	<v-col cols="4">
           <img src="imgs/characters/character_profiles_ramsey.jpg">
      </v-col>
      </v-row>
    </v-container>
</main>
</template>

<style scoped>
img {max-width: 100%}
h2 {color: white; text-transform: uppercase; padding-left: 10px;}
</style>