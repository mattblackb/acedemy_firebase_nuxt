<template>
  <main>
    <v-container>
      <h1>Site is currently undergoing maintenance</h1>
      <h2>Please see Patreon for updates</h2>
    </v-container>
  </main>
</template>

<script>
export default {}
</script>
<style scoped>
img {
  max-width: 100%;
}
</style>
