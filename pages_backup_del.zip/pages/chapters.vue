<template>
<main>
     <NavBar />
  <v-container>
        <v-row>
            <v-col cols="12">
                <h1>Chapters</h1>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12">
            <a href="/introductionDetails"  ><img src="/imgs/index_intro.jpg" /></a>
            </v-col>
        </v-row>
        
        <v-row> 
            <v-col cols="6">
                <a href="/chapter1Details"  ><img src="/imgs/index_ch1.jpg" /></a>
            </v-col>
             <v-col cols="6">
                <a href="/chapter2Details"  ><img src="/imgs/index_ch2.jpg" /></a>
            </v-col>
                  <v-col cols="6">
                <a href="/chapter3Details"  ><img src="/imgs/index_ch3.jpg" /></a>
            </v-col>
                  <v-col cols="6">
                <a href="/chapter4Details"  ><img src="/imgs/index_ch4.jpg" /></a>
            </v-col>
                  <v-col cols="6">
                <a href="/chapter5Details"  ><img src="/imgs/index_ch5.jpg" /></a>
            </v-col>
                  <v-col cols="6">
                <a href="/chapter6Details"  ><img src="/imgs/index_ch6.jpg" /></a>
            </v-col>
                  <v-col cols="6">
                <a href="/chapter7Details"  ><img src="/imgs/index_ch7.jpg" /></a>
            </v-col>
                  <v-col cols="6">
                <a href="/chapter8Details"  ><img src="/imgs/index_ch8.jpg" /></a>
            </v-col>
                  <v-col cols="6">
                <a href="/chapter9Details"  ><img src="/imgs/index_ch9.jpg" /></a>
            </v-col>
                  <v-col cols="6">
                <a href="/chapter10Details"  ><img src="/imgs/index_ch10.jpg" /></a>
            </v-col>
				  <v-col cols="6">
                <a href="/chapter11Details"  ><img src="/imgs/index_ch11.jpg" /></a>
            </v-col>
				  <v-col cols="6">
                <a href="/chapter12Details"  ><img src="/imgs/index_ch12.jpg" /></a>
            </v-col>
				  <v-col cols="6">
                <a href="/"  ><img src="/imgs/index_ch13_locked.jpg" /></a>
            </v-col>
				  <v-col cols="6">
                <a href="/"  ><img src="/imgs/index_ch14_locked.jpg" /></a>
            </v-col>
				  <v-col cols="6">
                <a href="/"  ><img src="/imgs/index_ch15_locked.jpg" /></a>
            </v-col>
				  <v-col cols="6">
                <a href="/"  ><img src="/imgs/index_ch16_locked.jpg" /></a>
            </v-col>
        </v-row>
        
        <v-row> 
           
        </v-row>
   
    </v-container>
</main>
</template>